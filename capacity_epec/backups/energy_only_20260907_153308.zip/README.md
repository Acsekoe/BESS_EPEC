# Capacity-only BESS EPEC

Three investors simultaneously choose nodal battery power `X_power[i,n]` and
energy `X_energy[i,n]` on the IEEE-9 network. Conditional on those capacities
the ISO clears a 24-hour market at minimum system cost. Each investor
maximises daily profit *through* that clearing, so the game is an EPEC: an
equilibrium problem whose every player solves an MPEC.

There is no quantity or price bidding. Capacity is the only strategic
variable. Investors share an optional physical nodal connection limit.

## Formulation

**Upper level** — one per investor, maximise daily profit:

```text
max   spot_revenue + generation_rent - degradation - daily_capex
s.t.  X_power[n] >= 0
      sum_i X_power[i,n] <= node_connection_limit[n]
      2 * X_power[n] <= X_energy[n] <= 8 * X_power[n]
      lower-level optimality conditions
```

`daily_capex` is the CRF-annualised overnight cost (6 600 EUR/MW,
18 800 EUR/MWh, 15-year life) divided by 365.25. `generation_rent` is the
owned renewable share times (LMP − true cost) times dispatch, which is what
makes I2 and I3 care about prices they do not set. Optional common quadratic
capacity curvature `qP`, `qE` defaults to zero.

`--node-limit-mw` overrides the cap uniformly for sensitivity cases; when it
is omitted the node-specific values in the input are used.

The affine nodal access tariff `alpha + beta * Q[n] / node_limit[n]` that this
model used to charge on each investor's own MW has been **removed**, for the
same reason the system-wide access auction before it was removed: it was a
symmetric cost that every investor faced identically, so its only effect on
the capacity split was to compress it towards equal shares. At `beta = 100`
and `L = 40` it supplied an own-curvature of `2*beta/L = 5` EUR/MW^2/day and
a marginal charge near 100 EUR/MW/day, and it produced a ~33/33/33 split at
every node. `tests/` asserts that neither the tariff nor the auction can be
reintroduced without the test failing.

The cap is a *shared* constraint, so it makes the game a GNEP: the investors'
feasible regions are coupled, the multiplier on the cap is not shared, and a
Jacobi iteration selects one arbitrary point from the continuum rather than a
unique equilibrium. `--node-limit-mw inf` switches it off. Switching it off
has to happen in one place for all three of the MPEC constraint, the candidate
screen and the exact reclear — deactivating only the MPEC constraint leaves
the screen and reclear still rejecting every oversubscribed profile, so a
deviation the MPEC is now free to propose could never be priced. An infinite
limit therefore builds no constraint *and* disarms the profile check.

The cap also censors the search whether or not it binds: with a 40 MW cap and
rivals already holding ~20 MW at a node, every `*_40mw_*` and `relocate_*`
multistart candidate is rejected before it is ever priced (37 of 75 candidates
in the `access_L40_A0_B100_20sweeps` run), so the large-capacity branch is
never seen.

`qP` and `qE` are **overnight portfolio-wide** coefficients. The quadratic
terms are `0.5*qP*(sum_n X_power[n])^2` and
`0.5*qE*(sum_n X_energy[n])^2`, then the CRF annualisation divides them by
365.25. Consequently the friction controls each investor's total scale but is
neutral to how that total is distributed across nodes.

**Lower level** — the ISO minimises daily system cost:

```text
min   sum_g,t offer[g] * P_gen[g,t]
    + sum_i,n,t 0.5 * degradation[i] * (P_charge + P_discharge)
    + 0.5 * penalty * sum_n,t DemandAdjustment[n,t]^2
s.t.  nodal balance, system balance, PTDF line limits (both directions),
      generation capacity, P_charge <= X_power, P_discharge <= X_power,
      SOC transition with efficiency eta, SOC <= X_energy, cyclic SOC.
```

Charge and discharge have separate power bounds; there is no shared-inverter
constraint. The quadratic demand-adjustment term is an ISO variable that
selects a unique LMP — it is not a strategic quantity anyone withholds. The
problem is a convex QP, so its KKT conditions and its strong duality are both
exact, and the dual of nodal balance is the LMP.

**Embedding** — `--formulation relaxed-kkt` (default) bounds every
complementarity product by `epsilon = 1e-4` (Scholtes); `--formulation
strong-duality` imposes the exact `primal == dual` equality instead. Both are
generated from the same list of products, so they cannot drift apart.

**Solution** — damped Jacobi: all three investors respond to the same frozen
profile, then move `--damping` of the way towards their answers. A moving
quadratic proximal term centred on the previous sweep stabilises the
iteration; it is always subtracted explicitly and never folded into a reported
profit. The final audit re-solves everything with the penalty at zero.

## Modules

| File | Role |
| --- | --- |
| [model/run_model.py](model/run_model.py) | CLI: build the config, run the game, write the outputs |
| [model/capacity_game.py](model/capacity_game.py) | Best responses, multistart search, damped Jacobi sweep, final audit |
| [model/mpec.py](model/mpec.py) | One investor's capacity MPEC — primal, duals, complementarity, profit |
| [model/iso_market.py](model/iso_market.py) | The ISO cost-minimisation QP and the settlement it implies |
| [model/investors.py](model/investors.py) | Investor parameters, capital recovery, the three-investor population |
| [model/market_data.py](model/market_data.py) | `MarketData` and the validated loader |
| [model/solvers.py](model/solvers.py) | IPOPT and Clarabel entry points, bound-violation check |
| [model/reporting.py](model/reporting.py) | CSV and JSON serialisation, nothing else |
| [model/input/market_data.json](model/input/market_data.json) | IEEE-9 network, demand, generation, PTDF |
| [tests/](tests/) | Regression tests for the failures that would otherwise be silent |

Dependencies run one way: `run_model` → `reporting`, `capacity_game` →
`mpec`, `iso_market` → `investors`, `market_data`, `solvers`.

Investors: `I1` merchant, `I2` 100% wind owner, and `I3` 100% PV owner. All
three use an 8% WACC; I2 owns every wind unit and I3 owns every PV unit.

The input JSON contains the default `node_connection_limit` for every node.
The cap is enforced against the active investor plus all frozen rival
capacities in every best response, exact candidate screen, and final audit.

## Environment

- Python 3.13, Pyomo 6.10.1 — see `requirements.txt`.
- IPOPT 3.13.2 with MA57. On this machine it is at
  `%LOCALAPPDATA%\idaes\bin\ipopt.exe`; put that directory on `PATH`, or set
  `IPOPT_EXECUTABLE`.
- NumPy, SciPy and Clarabel are required, not optional: the final audit
  compares every profit across two independent market solvers and cannot pass
  without both.

## Run

```powershell
$env:PATH = "$env:PATH;$env:LOCALAPPDATA\idaes\bin"
python model/run_model.py `
  --max-sweeps 60 `
  --damping 0.15 `
  --parallel-workers 4 `
  --output-dir model/output/capacity_baseline
```

`python model/run_model.py --help` groups the options by what they affect:
formulation, iteration, best-response search, audit, solver.

`--initial-capacities <csv>` starts the iteration from a stated profile in the
`final_capacities.csv` format (`investor,node,power_mw,energy_mwh`). This is
not a convenience: see *The congestion-relief threshold* below, which is why
the starting profile is a modelling choice rather than an implementation
detail.

Exit status is `0` only for an equilibrium candidate — the iteration converged
*and* the zero-proximal audit passed. Anything else exits `1`.

The output directory holds `run_config.json` (including the SHA-256 of the
input), `checkpoint.json`, `history.csv`, `current_capacities.csv`,
`final_capacities.csv`, `final_market.csv`, `profit_decomposition.csv`,
`final_audit.csv`, the per-sweep `starts_*.json` search records, `summary.json`,
and the two trajectories `capacity_by_investor_node_by_sweep.csv` and
`capacity_totals_by_investor_by_sweep.csv` (sweep 0 is the starting profile).

## Tests

```powershell
$env:PATH = "$env:PATH;$env:LOCALAPPDATA\idaes\bin"
python -m pytest -q tests/
```

## What the numbers do and do not show

Convergence is judged only on raw best-response deviations, never on the
damped step actually taken. Any candidate equilibrium is re-audited with the
proximal penalty at zero, and every capacity a solver proposes is re-cleared
in the exact market before being compared to anything.

IPOPT certifies local NLP solutions only. A converged Jacobi fixed point is
therefore not a proof of global best-response optimality; the multistart
search is a necessary check, not a sufficient one. `summary.json` says so
explicitly with `global_best_response_certified: false`.

The audit clears every incumbent and every deviation twice, once with IPOPT
and once with Clarabel, and reports the disagreement as
`final_profit_comparison_uncertainty_eur_per_day`. A profitable deviation
smaller than that number is solver noise, not an economic finding. This is an
empirical cross-check, not a rigorous error bound.

## The congestion-relief threshold

On this input the profit surface is not smooth in capacity, and that dominates
everything else about the game.

Midday PV (hours 11-16) congests the corridor into the N3-N6-N8-N9 pocket and
pins the LMP there at ~0 EUR/MWh in hours 13-15, while N1, N2, N4, N5 and N7
stay at 52-60. Storage in the pocket absorbs the surplus and releases the
price. That release is a *threshold*, not a gradient: over roughly 1-2 MW of
aggregate pocket capacity the mean pocket LMP steps from ~46 to ~54 EUR/MWh,
and because I3 earns `LMP * PV_dispatch` on ~4 500 MWh/day of PV, its daily
rent steps by more than 100 000 EUR. Inside that step the exact marginal
profit of a megawatt is of order 1e5 EUR/MW/day.

The two sides of the threshold are opposed interests, not a coordination
problem:

* I3 (PV owner) wants the pocket above the threshold — the step more than
  doubles its generation rent;
* I1 (merchant) wants it below — relieving the congestion collapses the very
  price spread its arbitrage lives on. Crossing takes I1's N8 position from
  +5 447 to -451 EUR/day.

A damped Jacobi iteration parks the profile *inside* the step, where no
investor is at a best response, and then reports convergence because the
capacity residual is small. It is small: in the `decoupled_B0_q50_20sweeps`
run the iteration stopped at a 0.26 MW residual while a 0.14 MW move was worth
67 840 EUR/day to I3. The zero-proximal audit is what catches this, and it is
the only reason that run is correctly reported as `converged: false`.

Two consequences for how this model is used:

1. **The capacity-norm stopping rule is not sufficient here.** `--tolerance-mw`
   and `--tolerance-mwh` cannot see a cliff. Only `final_audit.csv` and
   `summary.json`'s `final_profitable_deviation_eur_per_day` can, so a run is
   an equilibrium candidate only when `converged: true` — never on the strength
   of the per-sweep residuals printed during the iteration.
2. **The starting profile selects the basin.** Use `--initial-capacities` to
   enter each side deliberately and report both, rather than letting the
   symmetric default decide.

## Relation to `access_epec_minimal`

This folder remains distinct from the former system-wide access auction in
`access_epec_minimal/`: there is no global supply quantity `K`, projected price
update, or independent access-allocation variable. The present extension is a
physical nodal connection cap on installed MW. The nodal tariff that briefly
replaced that auction has since been removed as well; see *Formulation*.

Also removed as dead weight in a capacity-only model: load shedding and VOLL
(never reachable, since the demand-adjustment term already makes the market
feasible), the fixed storage capacities in the input file (capacities are
always supplied by the game), and the standalone market-clearing CLI.
