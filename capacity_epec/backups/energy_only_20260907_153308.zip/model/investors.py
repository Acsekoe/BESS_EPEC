"""Investor economics: financing, investment cost, and the maintained population."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Mapping

from market_data import MarketData


@dataclass(frozen=True)
class InvestorConfig:
    """One strategic investor.

    ``owned_generation_shares`` maps a generator to the fraction of its market
    rent this investor earns; it distinguishes renewable portfolio owners from
    pure merchants.
    """

    investor_id: str
    wacc: float = 0.08
    lifetime_years: int = 15
    cost_power_eur_per_mw: float = 6_600.0
    cost_energy_eur_per_mwh: float = 18_800.0
    degradation_eur_per_mwh: float = 15.0
    ratio_min: float = 2.0
    ratio_max: float = 8.0
    owned_generation_shares: Mapping[str, float] = field(default_factory=dict)
    quadratic_cost_power_eur_per_mw2: float = 0.0
    quadratic_cost_energy_eur_per_mwh2: float = 0.0

    def clip_duration(self, hours: float) -> float:
        """Project a duration onto this investor's admissible range."""

        return min(self.ratio_max, max(self.ratio_min, hours))


def capital_recovery_factor(wacc: float, lifetime_years: int) -> float:
    if wacc == 0.0:
        return 1.0 / lifetime_years
    growth = (1.0 + wacc) ** lifetime_years
    return wacc * growth / (growth - 1.0)


def daily_investment_cost(
    investor: InvestorConfig,
    power_values: Iterable[object],
    energy_values: Iterable[object],
) -> object:
    """Annualised daily capital cost of one nodal capacity portfolio.

    Accepts plain floats or Pyomo variables, so the same expression serves the
    MPEC objective and the post-solve accounting.
    """

    power_values = tuple(power_values)
    energy_values = tuple(energy_values)
    overnight = (
        investor.cost_power_eur_per_mw * sum(power_values)
        + investor.cost_energy_eur_per_mwh * sum(energy_values)
        + 0.5
        * investor.quadratic_cost_power_eur_per_mw2
        * (sum(power_values)) ** 2
        + 0.5
        * investor.quadratic_cost_energy_eur_per_mwh2
        * (sum(energy_values)) ** 2
    )
    return capital_recovery_factor(investor.wacc, investor.lifetime_years) / 365.25 * overnight


def three_investors(
    data: MarketData,
    *,
    quadratic_cost_power_eur_per_mw2: float = 0.0,
    quadratic_cost_energy_eur_per_mwh2: float = 0.0,
) -> tuple[InvestorConfig, ...]:
    """The maintained population: merchant, wind owner, and solar owner.

    All three investors use an 8% WACC. I2 owns all wind generation and I3
    owns all PV generation, so their only economic asymmetry relative to the
    merchant I1 is their generation portfolio.
    """

    wind = [generator for generator in data.generators if "Wind" in generator]
    solar = [generator for generator in data.generators if "PV" in generator]
    if not wind or not solar:
        raise ValueError("The three-investor population requires wind and PV generation.")

    common = {
        "quadratic_cost_power_eur_per_mw2": quadratic_cost_power_eur_per_mw2,
        "quadratic_cost_energy_eur_per_mwh2": quadratic_cost_energy_eur_per_mwh2,
    }
    return (
        InvestorConfig("I1", wacc=0.08, **common),
        InvestorConfig(
            "I2",
            wacc=0.08,
            owned_generation_shares={generator: 1.0 for generator in wind},
            **common,
        ),
        InvestorConfig(
            "I3",
            wacc=0.08,
            owned_generation_shares={generator: 1.0 for generator in solar},
            **common,
        ),
    )
