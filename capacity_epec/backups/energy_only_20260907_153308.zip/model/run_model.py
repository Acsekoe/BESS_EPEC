"""Run the three-investor IEEE-9 BESS capacity game.

Nodal power and energy capacity are the only strategic variables.  Conditional
on them the ISO dispatches at minimum system cost, and that dispatch is
embedded in each investor's problem through relaxed KKT conditions or exact
strong duality.

    python model/run_model.py --max-sweeps 60 --damping 0.15

Exit status is 0 only for an equilibrium candidate: the iteration converged
*and* the zero-proximal audit passed.  Anything else exits 1.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
from dataclasses import asdict
from pathlib import Path

import reporting
from capacity_game import GameConfig, GameState, audit_equilibrium, initial_state, run_jacobi
from investors import three_investors
from iso_market import settle
from market_data import DEFAULT_DATA_PATH, load_market_data
from solvers import MARKET_BACKENDS, SolverSettings


DEFAULT_OUTPUT = Path(__file__).resolve().parent / "output" / "capacity_game"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA_PATH)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)

    formulation = parser.add_argument_group("formulation")
    formulation.add_argument(
        "--formulation", choices=("relaxed-kkt", "strong-duality"), default="relaxed-kkt"
    )
    formulation.add_argument("--complementarity-epsilon", type=float, default=1.0e-4)
    formulation.add_argument(
        "--quadratic-cost-power-eur-per-mw2",
        type=float,
        default=0.0,
        help=(
            "Common portfolio power-cost curvature; adds 0.5*qP*(sum_n X_power[n])^2 "
            "to the OVERNIGHT cost, which the CRF then annualises by ~3.2e-4."
        ),
    )
    formulation.add_argument(
        "--quadratic-cost-energy-eur-per-mwh2",
        type=float,
        default=0.0,
        help=(
            "Common portfolio energy-cost curvature; adds 0.5*qE*(sum_n X_energy[n])^2 "
            "to the overnight cost, annualised by the same ~3.2e-4 factor."
        ),
    )

    access = parser.add_argument_group("nodal BESS connection")
    access.add_argument(
        "--node-limit-mw",
        type=float,
        default=None,
        help=(
            "Uniform aggregate BESS MW cap at every node; default uses the input limits. "
            "Pass 'inf' to switch the shared cap off in the MPEC, the candidate screen "
            "and the exact reclear at once."
        ),
    )

    iteration = parser.add_argument_group("iteration")
    iteration.add_argument("--max-sweeps", type=int, default=60)
    iteration.add_argument("--damping", type=float, default=0.25)
    iteration.add_argument("--consecutive-sweeps", type=int, default=2)
    iteration.add_argument("--tolerance-mw", type=float, default=0.5)
    iteration.add_argument("--tolerance-mwh", type=float, default=1.0)
    iteration.add_argument("--proximal-penalty", type=float, default=0.01)
    iteration.add_argument("--initial-power-mw", type=float, default=5.0)
    iteration.add_argument("--initial-ratio-hours", type=float, default=3.0)
    start = iteration.add_mutually_exclusive_group()
    start.add_argument(
        "--symmetric-initialization", dest="symmetric_initialization", action="store_true"
    )
    start.add_argument(
        "--asymmetric-initialization", dest="symmetric_initialization", action="store_false"
    )
    parser.set_defaults(symmetric_initialization=True)
    iteration.add_argument(
        "--initial-capacities",
        type=Path,
        default=None,
        help=(
            "CSV with investor,node,power_mw,energy_mwh to start from (the format of "
            "final_capacities.csv). Overrides the symmetric and historical starts."
        ),
    )

    search = parser.add_argument_group("best-response search")
    search.add_argument(
        "--multistart-every-sweeps",
        type=int,
        default=5,
        help="Multistart on sweep 1 and every N sweeps; 0 disables it.",
    )
    search.add_argument("--refinement-starts", type=int, default=3)

    audit = parser.add_argument_group("audit")
    audit.add_argument("--audit-profit-tolerance-eur-per-day", type=float, default=1.0)
    audit.add_argument("--audit-reclear-gap-tolerance-eur-per-day", type=float, default=10.0)

    solver = parser.add_argument_group("solver")
    solver.add_argument("--exact-market-solver", choices=MARKET_BACKENDS, default="ipopt")
    solver.add_argument("--parallel-workers", type=int, default=4)
    solver.add_argument("--ipopt-linear-solver", default="ma57")
    solver.add_argument("--max-solver-iterations", type=int, default=3_000)
    solver.add_argument("--max-solve-seconds", type=float, default=600.0)
    solver.add_argument("--solver-tolerance", type=float, default=1.0e-6)
    solver.add_argument("--tee", action="store_true")
    return parser.parse_args()


def build_config(args: argparse.Namespace, data) -> GameConfig:
    if args.quadratic_cost_power_eur_per_mw2 < 0.0 or args.quadratic_cost_energy_eur_per_mwh2 < 0.0:
        raise ValueError("Quadratic investment-cost coefficients cannot be negative.")
    if args.node_limit_mw is not None and not args.node_limit_mw > 0.0:
        raise ValueError("The node limit must be positive.")
    return GameConfig(
        investors=three_investors(
            data,
            quadratic_cost_power_eur_per_mw2=args.quadratic_cost_power_eur_per_mw2,
            quadratic_cost_energy_eur_per_mwh2=args.quadratic_cost_energy_eur_per_mwh2,
        ),
        lower_level=args.formulation,
        complementarity_epsilon=args.complementarity_epsilon,
        max_sweeps=args.max_sweeps,
        damping=args.damping,
        consecutive_sweeps=args.consecutive_sweeps,
        tolerance_mw=args.tolerance_mw,
        tolerance_mwh=args.tolerance_mwh,
        multistart_every_sweeps=args.multistart_every_sweeps,
        refinement_starts=args.refinement_starts,
        proximal_penalty=args.proximal_penalty,
        uniform_node_connection_limit_mw=args.node_limit_mw,
        symmetric_initialization=args.symmetric_initialization,
        initial_power_mw=args.initial_power_mw,
        initial_ratio_hours=args.initial_ratio_hours,
        audit_profit_tolerance_eur_per_day=args.audit_profit_tolerance_eur_per_day,
        audit_reclear_gap_tolerance_eur_per_day=args.audit_reclear_gap_tolerance_eur_per_day,
        parallel_workers=args.parallel_workers,
        solver=SolverSettings(
            market_backend=args.exact_market_solver,
            linear_solver=args.ipopt_linear_solver,
            max_iterations=args.max_solver_iterations,
            max_seconds=args.max_solve_seconds,
            tolerance=args.solver_tolerance,
            tee=args.tee,
        ),
    )


def main() -> int:
    args = parse_args()
    data = load_market_data(args.data)
    config = build_config(args, data)
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)

    reporting.write_json(
        out / "run_config.json",
        reporting.run_config(
            config, args.data, hashlib.sha256(args.data.read_bytes()).hexdigest()
        ),
    )

    state = initial_state(data, config, read_capacities(args.initial_capacities))
    nodal_trajectory = reporting.capacity_rows(
        data, config.investors, state.power, state.energy, sweep=0
    )
    total_trajectory = reporting.capacity_total_rows(
        data, config.investors, state.power, state.energy, sweep=0
    )

    def on_sweep(state: GameState) -> None:
        row = state.history[-1]
        print(
            f"sweep={state.sweep:03d} "
            f"power_residual={row['max_raw_power_deviation_mw']:.4f} MW "
            f"energy_residual={row['max_raw_energy_deviation_mwh']:.4f} MWh "
            f"total_power={row['total_power_mw']:.3f} MW "
            f"optimal={row['all_best_responses_optimal']}",
            flush=True,
        )
        nodal_trajectory.extend(
            reporting.capacity_rows(
                data, config.investors, state.power, state.energy, sweep=state.sweep
            )
        )
        total_trajectory.extend(
            reporting.capacity_total_rows(
                data, config.investors, state.power, state.energy, sweep=state.sweep
            )
        )
        reporting.write_rows(out / "history.csv", state.history)
        reporting.write_rows(out / "capacity_by_investor_node_by_sweep.csv", nodal_trajectory)
        reporting.write_rows(out / "capacity_totals_by_investor_by_sweep.csv", total_trajectory)
        reporting.write_rows(
            out / "current_capacities.csv",
            reporting.capacity_rows(data, config.investors, state.power, state.energy),
        )
        reporting.write_json(out / "checkpoint.json", reporting.checkpoint(state, config))
        reporting.write_json(
            out / f"starts_sweep_{state.sweep:03d}.json",
            {unit: response.start_records for unit, response in state.responses.items()},
        )

    print(
        f"Capacity-only EPEC: formulation={config.lower_level}, "
        f"investors={len(config.investors)}, workers={config.parallel_workers}",
        flush=True,
    )
    state = run_jacobi(data, config, initial=state, on_sweep=on_sweep)
    report = audit_equilibrium(data, config, state)

    reporting.write_rows(
        out / "final_capacities.csv",
        reporting.capacity_rows(data, config.investors, state.power, state.energy),
    )
    reporting.write_rows(out / "final_audit.csv", [asdict(row) for row in report.rows])
    reporting.write_json(
        out / "starts_final_audit.json",
        {unit: response.start_records for unit, response in state.responses.items()},
    )
    if report.market is not None:
        reporting.write_rows(out / "final_market.csv", reporting.market_rows(report.market, data))
        reporting.write_rows(
            out / "profit_decomposition.csv",
            [
                asdict(settle(report.market, data, investor, state.power, state.energy))
                for investor in config.investors
            ],
        )

    summary = build_summary(data, config, state, report)
    reporting.write_json(out / "summary.json", summary)
    reporting.write_json(out / "checkpoint.json", reporting.checkpoint(state, config))
    print(reporting.json_dumps(summary, indent=2), flush=True)
    return 0 if summary["converged"] else 1


def read_capacities(path: Path | None):
    """Read a starting profile from a `final_capacities.csv`-shaped file."""

    if path is None:
        return None
    power: dict[tuple[str, str], float] = {}
    energy: dict[tuple[str, str], float] = {}
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            key = (row["investor"], row["node"])
            power[key] = float(row["power_mw"])
            energy[key] = float(row["energy_mwh"])
    if not power:
        raise ValueError(f"No capacity rows in {path}.")
    return power, energy


def build_summary(data, config: GameConfig, state: GameState, report) -> dict[str, object]:
    equilibrium_candidate = state.converged and report.passed
    stop_reason = state.stop_reason
    if state.converged and not report.passed:
        stop_reason = "iteration converged but the zero-proximal final audit failed"
    nodal_power = {
        node: sum(state.power[unit, node] for unit in config.investor_ids)
        for node in data.nodes
    }
    node_limits = config.node_limits(data)
    return {
        "formulation": f"capacity-only-{config.lower_level}",
        "strategic_variables": ["power_capacity", "energy_capacity"],
        "operational_bidding": False,
        "converged": equilibrium_candidate,
        "iteration_converged": state.converged,
        "local_zero_proximal_audit_valid": report.valid,
        "local_zero_proximal_audit_passed": report.passed,
        # IPOPT certifies local solutions only; multistart is a search, not a proof.
        "global_best_response_certified": False,
        "final_market_valid": report.market is not None,
        "sweeps": state.sweep,
        "stop_reason": stop_reason,
        "total_power_mw": state.total_power_mw(),
        "total_energy_mwh": state.total_energy_mwh(),
        "maximum_nodal_capacity_mw": max(nodal_power.values()),
        "nodal_power_mw": nodal_power,
        "shared_node_cap_enforced": config.shared_node_cap_enforced,
        "node_connection_limit_mw": node_limits,
        "nodal_connection_utilization": {
            node: nodal_power[node] / node_limits[node] for node in data.nodes
        },
        "final_raw_power_residual_mw": report.worst("max_power_deviation_mw"),
        "final_raw_energy_residual_mwh": report.worst("max_energy_deviation_mwh"),
        "final_profitable_deviation_eur_per_day": report.worst(
            "profitable_deviation_eur_per_day"
        ),
        "final_embedded_reclear_profit_gap_eur_per_day": report.worst(
            "embedded_reclear_profit_gap_eur_per_day"
        ),
        "final_complementarity_violation": report.worst("complementarity_max_violation"),
        "final_profit_comparison_uncertainty_eur_per_day": report.worst(
            "profit_comparison_uncertainty_eur_per_day"
        ),
        "final_crosschecked_profitable_deviation_eur_per_day": report.worst(
            "crosschecked_profitable_deviation_eur_per_day"
        ),
        "capacity_trajectory_file": "capacity_by_investor_node_by_sweep.csv",
        "investor_totals_trajectory_file": "capacity_totals_by_investor_by_sweep.csv",
    }


if __name__ == "__main__":
    raise SystemExit(main())
