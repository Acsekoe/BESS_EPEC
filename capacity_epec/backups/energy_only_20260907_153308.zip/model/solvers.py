"""Everything this project needs from a solver.

Two very different solves happen here:

* the ISO's fixed-capacity market, a convex QP that must be solved tightly
  because its duals *are* the LMPs (IPOPT at a hard tolerance, or Clarabel as
  an independent second opinion); and
* an investor's capacity MPEC, a non-convex NLP for which IPOPT returns a
  local solution that always has to be audited afterwards.
"""

from __future__ import annotations

import math
import os
import shutil
import time
from dataclasses import dataclass
from pathlib import Path

import pyomo.environ as pyo
from pyomo.repn import generate_standard_repn


MARKET_BACKENDS = ("ipopt", "clarabel")


@dataclass(frozen=True)
class SolverSettings:
    """Solver choices shared by the market QP and the capacity MPEC."""

    market_backend: str = "ipopt"
    linear_solver: str = "ma57"
    max_iterations: int = 3_000
    max_seconds: float = 45
    tolerance: float = 1.0e-6
    tee: bool = False
    executable: str | None = None

    def __post_init__(self) -> None:
        if self.market_backend not in MARKET_BACKENDS:
            raise ValueError(f"Unknown market backend: {self.market_backend}")
        if self.tolerance <= 0.0:
            raise ValueError("The solver tolerance must be positive.")
        if self.max_iterations <= 0 or self.max_seconds <= 0.0:
            raise ValueError("Solver iteration and time limits must be positive.")


@dataclass(frozen=True)
class SolveOutcome:
    """What one MPEC solve returned, before any economic interpretation."""

    termination: str
    has_solution: bool
    optimal: bool
    seconds: float


def ipopt_path(settings: SolverSettings) -> Path | None:
    """First IPOPT binary that actually exists, or None to let Pyomo look."""

    candidates = [
        settings.executable,
        os.environ.get("IPOPT_EXECUTABLE"),
        shutil.which("ipopt"),
        (
            str(Path(os.environ["LOCALAPPDATA"]) / "idaes" / "bin" / "ipopt.exe")
            if os.environ.get("LOCALAPPDATA")
            else None
        ),
    ]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return Path(candidate)
    return None


def _ipopt(settings: SolverSettings, options: dict[str, object]):
    kwargs: dict[str, object] = {"solver_io": "nl"}
    executable = ipopt_path(settings)
    if executable is not None:
        kwargs["executable"] = str(executable)
    solver = pyo.SolverFactory("ipopt", **kwargs)
    if not solver.available(exception_flag=False):
        raise RuntimeError("IPOPT is unavailable.")
    solver.options.update(options)
    return solver


def solve_market_qp(model: pyo.ConcreteModel, settings: SolverSettings) -> None:
    """Solve a fixed-capacity market to optimality and import its duals.

    Raises if the QP does not solve: an unsolved market has no LMPs, and a
    silently degraded one would corrupt every profit downstream.
    """

    if settings.market_backend == "clarabel":
        solve_with_clarabel(model)
        return
    solver = _ipopt(
        settings,
        {
            "linear_solver": settings.linear_solver,
            "max_iter": settings.max_iterations,
            "max_cpu_time": settings.max_seconds,
            # The duals are prices, so this solve is deliberately tighter than
            # the strategic NLP above it.
            "tol": min(settings.tolerance, 1.0e-11),
            "acceptable_tol": 1.0e-10,
            "bound_relax_factor": 0.0,
            "honor_original_bounds": "yes",
            "warm_start_init_point": "no",
            "print_level": 0,
        },
    )
    result = solver.solve(model, tee=False)
    if result.solver.termination_condition != pyo.TerminationCondition.optimal:
        raise RuntimeError(
            f"Market clearing failed: {result.solver.termination_condition}"
        )


def solve_mpec(model: pyo.ConcreteModel, settings: SolverSettings) -> SolveOutcome:
    """Solve one investor's capacity MPEC; never raises on a bad termination."""

    solver = _ipopt(
        settings,
        {
            "linear_solver": settings.linear_solver,
            "max_iter": settings.max_iterations,
            "max_cpu_time": settings.max_seconds,
            "tol": settings.tolerance,
            "acceptable_tol": max(settings.tolerance, 1.0e-4),
            "constr_viol_tol": settings.tolerance,
            "bound_relax_factor": 0.0,
            "honor_original_bounds": "yes",
            # Pyomo still exports every Var.value as the primal start; "no"
            # only stops IPOPT importing stale bound/constraint multipliers.
            "warm_start_init_point": "no",
            "print_level": 5 if settings.tee else 0,
        },
    )
    started = time.perf_counter()
    try:
        result = solver.solve(model, tee=settings.tee)
        termination = result.solver.termination_condition
        optimal = termination in {
            pyo.TerminationCondition.optimal,
            pyo.TerminationCondition.locallyOptimal,
        }
        has_solution = optimal or termination == pyo.TerminationCondition.feasible
        return SolveOutcome(
            str(termination), has_solution, optimal, time.perf_counter() - started
        )
    except Exception as exc:  # a crashed solve is a failed start, not a run failure
        return SolveOutcome(
            f"error: {exc}", False, False, time.perf_counter() - started
        )


def maximum_bound_violation(model: pyo.ConcreteModel) -> float:
    """Worst violation of any variable or constraint bound at the current point.

    Returns infinity when anything is unevaluable, so a broken point can never
    be mistaken for a feasible one.
    """

    worst = 0.0
    components = list(model.component_data_objects(pyo.Var)) + list(
        model.component_data_objects(pyo.Constraint, active=True)
    )
    for component in components:
        body = component if component.ctype is pyo.Var else component.body
        value = pyo.value(body, exception=False)
        if value is None or not math.isfinite(value):
            return math.inf
        for bound, sign in ((component.lb, -1), (component.ub, 1)):
            if bound is not None:
                worst = max(worst, sign * (value - pyo.value(bound)))
    return worst


def solve_with_clarabel(model: pyo.ConcreteModel, tolerance: float = 1e-10) -> None:
    """Solve a convex Pyomo QP with Clarabel, writing back values and duals.

    This is the independent second opinion on the market QP: a different
    algorithm on the same model, used to bound how much of a reported profit
    difference is numerical rather than economic.
    """

    import numpy as np
    import scipy.sparse as sp
    import clarabel

    variables = list(model.component_data_objects(pyo.Var))
    position = {id(variable): j for j, variable in enumerate(variables)}
    size = len(variables)

    objective = next(model.component_data_objects(pyo.Objective, active=True))
    repn = generate_standard_repn(objective.expr)
    if repn.nonlinear_expr is not None or objective.sense != pyo.minimize:
        raise ValueError("Expected a convex minimization QP.")

    linear = np.zeros(size)
    for variable, coefficient in zip(repn.linear_vars, repn.linear_coefs):
        linear[position[id(variable)]] += float(coefficient)
    rows, cols, values = [], [], []
    for (first, second), coefficient in zip(repn.quadratic_vars, repn.quadratic_coefs):
        j, k = sorted((position[id(first)], position[id(second)]))
        rows.append(j)
        cols.append(k)
        values.append(float(coefficient) * (2 if j == k else 1))
    quadratic = sp.csc_matrix((values, (rows, cols)), shape=(size, size))

    # Clarabel wants A x + s = b with s in a cone: equality rows first, then
    # every one-sided row, each remembering which Pyomo constraint it came
    # from and with which sign so the duals can be written back.
    equalities: list[tuple[list[tuple[int, float]], float, object, int]] = []
    inequalities: list[tuple[list[tuple[int, float]], float, object, int]] = []
    for constraint in model.component_data_objects(pyo.Constraint, active=True):
        body = generate_standard_repn(constraint.body)
        if not body.is_linear():
            raise ValueError(f"Nonlinear constraint {constraint.name}.")
        terms = [
            (position[id(variable)], float(coefficient))
            for variable, coefficient in zip(body.linear_vars, body.linear_coefs)
        ]
        constant = float(body.constant or 0.0)
        if constraint.equality:
            equalities.append(
                (terms, float(pyo.value(constraint.upper)) - constant, constraint, 1)
            )
            continue
        if constraint.upper is not None:
            inequalities.append(
                (terms, float(pyo.value(constraint.upper)) - constant, constraint, 1)
            )
        if constraint.lower is not None:
            inequalities.append(
                (
                    [(j, -coefficient) for j, coefficient in terms],
                    constant - float(pyo.value(constraint.lower)),
                    constraint,
                    -1,
                )
            )
    for j, variable in enumerate(variables):
        if variable.fixed:
            equalities.append(([(j, 1.0)], float(pyo.value(variable)), None, 1))
            continue
        if variable.ub is not None:
            inequalities.append(([(j, 1.0)], float(variable.ub), None, 1))
        if variable.lb is not None:
            inequalities.append(([(j, -1.0)], -float(variable.lb), None, -1))

    all_rows = equalities + inequalities
    ar, ac, av = [], [], []
    for k, (terms, _, _, _) in enumerate(all_rows):
        for j, coefficient in terms:
            ar.append(k)
            ac.append(j)
            av.append(coefficient)
    matrix = sp.csc_matrix((av, (ar, ac)), shape=(len(all_rows), size))
    rhs = np.array([row[1] for row in all_rows])
    cones = [
        clarabel.ZeroConeT(len(equalities)),
        clarabel.NonnegativeConeT(len(inequalities)),
    ]

    def run(tol: float):
        settings = clarabel.DefaultSettings()
        settings.verbose = False
        settings.max_iter = 300
        settings.tol_gap_abs = tol
        settings.tol_gap_rel = tol
        settings.tol_feas = tol
        return clarabel.DefaultSolver(
            quadratic, linear, matrix, rhs, cones, settings
        ).solve()

    solution = run(tolerance)
    if str(solution.status) == "AlmostSolved":
        # Degenerate near-zero batteries can hit the numerical floor at 1e-10.
        # Retry once at 1e-9; never silently accept a failed status.
        solution = run(1e-9)
    if str(solution.status) != "Solved":
        raise RuntimeError(
            f"Clarabel: {solution.status}; primal={solution.r_prim}; "
            f"dual={solution.r_dual}; "
            f"gap={abs(solution.obj_val - solution.obj_val_dual)}"
        )

    for variable, value in zip(variables, solution.x):
        variable.set_value(value, skip_validation=True)
    if not hasattr(model, "dual"):
        model.dual = pyo.Suffix(direction=pyo.Suffix.IMPORT)
    model.dual.clear()
    for (_, _, constraint, sign), dual in zip(all_rows, solution.z):
        if constraint is not None:
            model.dual[constraint] = model.dual.get(constraint, 0.0) - sign * dual

    violation = maximum_bound_violation(model)
    if violation > 1e-6:
        raise RuntimeError(
            f"Clarabel returned an infeasible point: violation={violation}"
        )
