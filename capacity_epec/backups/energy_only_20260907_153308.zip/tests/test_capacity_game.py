"""Regression tests for the parts of the capacity game that can fail quietly.

These target economically material failures: an audit that passes on missing
numbers, a search that silently skips part of the capacity space, prices with
the wrong sign, or a candidate deviation lost because a local solve crashed.
"""

from __future__ import annotations

import math
import sys
from dataclasses import replace
from pathlib import Path

import pytest
import pyomo.environ as pyo

MODEL_DIR = Path(__file__).resolve().parents[1] / "model"
sys.path.insert(0, str(MODEL_DIR))

import capacity_game as game
import mpec
import solvers
from investors import daily_investment_cost, three_investors
from iso_market import settle
from market_data import load_market_data


@pytest.fixture(scope="module")
def data():
    return load_market_data()


def one_investor_config(data, **overrides) -> game.GameConfig:
    return game.GameConfig(
        investors=(three_investors(data)[0],), parallel_workers=1, **overrides
    )


# ---------------------------------------------------------------- population


def test_maintained_population_is_merchant_wind_and_solar(data):
    investors = three_investors(data)
    assert [investor.investor_id for investor in investors] == ["I1", "I2", "I3"]
    assert all(investor.wacc == pytest.approx(0.08) for investor in investors)

    wind = {generator for generator in data.generators if "Wind" in generator}
    solar = {generator for generator in data.generators if "PV" in generator}
    assert dict(investors[0].owned_generation_shares) == {}
    assert dict(investors[1].owned_generation_shares) == {
        generator: 1.0 for generator in wind
    }
    assert dict(investors[2].owned_generation_shares) == {
        generator: 1.0 for generator in solar
    }


def test_quadratic_investment_cost_is_portfolio_wide(data):
    investor = three_investors(
        data,
        quadratic_cost_power_eur_per_mw2=20_000.0,
        quadratic_cost_energy_eur_per_mwh2=5_000.0,
    )[0]
    concentrated = daily_investment_cost(investor, [10.0, 0.0], [30.0, 0.0])
    distributed = daily_investment_cost(investor, [5.0, 5.0], [15.0, 15.0])
    assert concentrated == pytest.approx(distributed)


# --------------------------------------------------------------------- search


def test_multistart_probes_every_node(data):
    config = game.GameConfig(investors=three_investors(data))
    state = game.initial_state(data, config)
    labels = {
        label
        for label, _, _ in game.capacity_starts(
            data, config, config.investors[0], state.power, state.energy
        )
    }
    for node in data.nodes:
        assert f"replace_{node}_40mw_4h" in labels
        assert f"relocate_{node}" in labels
    assert {"incumbent", "zero", "scaled_up", "shrunken"} <= labels


def test_feasible_candidate_survives_a_failed_refinement(data, monkeypatch):
    config = one_investor_config(data, proximal_penalty=0.0, refinement_starts=1)
    state = game.initial_state(data, config)
    monkeypatch.setattr(game, "clear", lambda *a: object())
    monkeypatch.setattr(
        game,
        "recleared_profit",
        lambda m, d, c, i, p, e: -((sum(p.values()) - 40.0) ** 2),
    )
    monkeypatch.setattr(
        game,
        "solve_from_start",
        lambda *a: (_ for _ in ()).throw(RuntimeError("deliberate local failure")),
    )
    response = game.best_response(
        data, config, config.investors[0], state.power, state.energy, use_multistart=True
    )
    # Screening found a feasible, profitable capacity even though every local
    # refinement crashed: that candidate must not be thrown away.
    assert response.outcome.has_solution and not response.outcome.optimal
    assert math.isfinite(response.recleared_profit_eur_per_day)
    assert any(
        row["phase"] == "refine" and "deliberate" in row["error"]
        for row in response.start_records
    )
    assert sum(bool(row["selected"]) for row in response.start_records) == 1


# ----------------------------------------------------------------- formulation


def test_relaxed_products_are_bounded_above_only(data):
    investor = three_investors(data)[0]
    rivals = {unit: {node: 0.0 for node in data.nodes} for unit in ("I2", "I3")}
    model = mpec.build_capacity_mpec(
        data,
        investor=investor,
        rival_power=rivals,
        rival_energy=rivals,
        lower_level="relaxed-kkt",
        complementarity_epsilon=1.0e-4,
    )
    constraint = next(iter(model.complementarity_generation_lower.values()))
    assert constraint.lower is None
    assert pyo.value(constraint.upper) == 1.0e-4
    assert not model.strong_duality.active


def test_strong_duality_uses_the_exact_equality_and_no_relaxation(data):
    investor = three_investors(data)[0]
    rivals = {unit: {node: 0.0 for node in data.nodes} for unit in ("I2", "I3")}
    model = mpec.build_capacity_mpec(
        data,
        investor=investor,
        rival_power=rivals,
        rival_energy=rivals,
        lower_level="strong-duality",
    )
    assert model.strong_duality.active
    assert not hasattr(model, "complementarity_generation_lower")
    # Both formulations still report the same products, at epsilon zero.
    assert mpec.context(model).complementarity_epsilon == 0.0
    assert len(mpec.context(model).product_components) == 10


def test_shared_nodal_connection_limit_bounds_the_active_investor(data):
    investor = three_investors(data)[0]
    rivals = {
        "I2": {node: 10.0 for node in data.nodes},
        "I3": {node: 12.0 for node in data.nodes},
    }
    model = mpec.build_capacity_mpec(
        data,
        investor=investor,
        rival_power=rivals,
        rival_energy={
            unit: {node: 3.0 * value for node, value in values.items()}
            for unit, values in rivals.items()
        },
        node_connection_limit={node: 40.0 for node in data.nodes},
    )
    for node in data.nodes:
        model.X_power[node].set_value(18.0)
        assert pyo.value(model.node_connection_limit[node].body) == pytest.approx(40.0)
        assert pyo.value(model.node_connection_limit[node].upper) == pytest.approx(40.0)


def test_an_infinite_node_limit_decouples_the_investors(data):
    """An infinite limit must switch the shared cap off everywhere at once.

    Deactivating only the MPEC constraint would leave the exact screen and
    reclear still rejecting every oversubscribed profile, so a best response
    that the MPEC is now free to propose could never be priced.
    """

    investor = three_investors(data)[0]
    rivals = {
        "I2": {node: 10.0 for node in data.nodes},
        "I3": {node: 12.0 for node in data.nodes},
    }
    model = mpec.build_capacity_mpec(
        data,
        investor=investor,
        rival_power=rivals,
        rival_energy={
            unit: {node: 3.0 * value for node, value in values.items()}
            for unit, values in rivals.items()
        },
        node_connection_limit={node: math.inf for node in data.nodes},
    )
    assert len(model.node_connection_limit) == 0

    config = game.GameConfig(
        investors=three_investors(data),
        parallel_workers=1,
        uniform_node_connection_limit_mw=math.inf,
    )
    oversubscribed = {
        (unit, node): 500.0 for unit in config.investor_ids for node in data.nodes
    }
    game._check_profile_node_limits(data, config, oversubscribed)

    capped = replace(config, uniform_node_connection_limit_mw=40.0)
    with pytest.raises(ValueError, match="connection limit exceeded"):
        game._check_profile_node_limits(data, capped, oversubscribed)


# ---------------------------------------------------------------------- market


def test_clarabel_matches_the_expected_primal_and_dual_signs():
    model = pyo.ConcreteModel()
    model.x = pyo.Var(domain=pyo.NonNegativeReals)
    model.y = pyo.Var()
    model.balance = pyo.Constraint(expr=model.x + model.y == 3)
    model.cap = pyo.Constraint(expr=model.x <= 1)
    model.objective = pyo.Objective(expr=model.y**2)
    solvers.solve_with_clarabel(model)
    assert pyo.value(model.x) == pytest.approx(1.0, abs=1e-7)
    assert model.dual[model.balance] == pytest.approx(4.0, abs=1e-7)
    assert model.dual[model.cap] == pytest.approx(-4.0, abs=1e-7)
    assert solvers.maximum_bound_violation(model) < 1e-7


def test_settlement_decomposition_adds_up(data):
    config = game.GameConfig(investors=three_investors(data), parallel_workers=1)
    state = game.initial_state(data, config)
    market = game.clear(data, config, state.power, state.energy)
    for investor in config.investors:
        row = settle(market, data, investor, state.power, state.energy)
        assert row.storage_operating_surplus == pytest.approx(
            row.storage_settlement - row.degradation
        )
        assert row.profit == pytest.approx(
            row.storage_settlement
            + row.owned_generation_rent
            - row.degradation
            - row.capex
        )
        assert row.capex > 0.0


# ----------------------------------------------------------------------- audit


def test_audit_switches_the_proximal_penalty_off(data, monkeypatch):
    investor = three_investors(data)[0]
    config = one_investor_config(data, proximal_penalty=0.25)
    state = game.GameState(
        power={(investor.investor_id, node): 1.0 for node in data.nodes},
        energy={(investor.investor_id, node): 3.0 for node in data.nodes},
    )
    response = game.BestResponse(
        investor_id=investor.investor_id,
        outcome=solvers.SolveOutcome("optimal", True, True, 0.0),
        power={node: 1.0 for node in data.nodes},
        energy={node: 3.0 for node in data.nodes},
        embedded_profit_eur_per_day=10.0,
        max_complementarity_product=0.0,
        max_complementarity_violation=0.0,
        primal_dual_gap_eur_per_day=0.0,
        max_bound_violation=0.0,
    )
    seen = {}

    def fake_audit_state(_data, audit_config, _state):
        seen["penalty"] = audit_config.proximal_penalty
        return {investor.investor_id: response}

    monkeypatch.setattr(game, "clear", lambda *a: object())
    monkeypatch.setattr(game, "recleared_profit", lambda *a: 10.0)
    monkeypatch.setattr(game, "audit_state", fake_audit_state)

    report = game.audit_equilibrium(data, config, state)
    assert seen["penalty"] == 0.0
    assert report.valid and report.rows[0].profitable_deviation_eur_per_day == 0.0
    assert report.passed


def test_a_failed_common_reclear_can_never_pass(data, monkeypatch):
    config = game.GameConfig(investors=three_investors(data))
    state = game.initial_state(data, config)
    monkeypatch.setattr(
        game, "clear", lambda *a: (_ for _ in ()).throw(RuntimeError("reclear failed"))
    )
    report = game.audit_equilibrium(data, config, state)
    assert report.market is None and len(report.rows) == 3
    assert not report.valid and not report.passed
    assert all(math.isnan(row.profitable_deviation_eur_per_day) for row in report.rows)


def test_a_missing_number_is_not_a_passing_number(data, monkeypatch):
    investor = three_investors(data)[0]
    config = one_investor_config(data)
    state = game.GameState(
        power={(investor.investor_id, node): 1.0 for node in data.nodes},
        energy={(investor.investor_id, node): 3.0 for node in data.nodes},
    )
    response = game.BestResponse(
        investor_id=investor.investor_id,
        outcome=solvers.SolveOutcome("error", False, False, 0.0),
        power={node: 1.0 for node in data.nodes},
        energy={node: 3.0 for node in data.nodes},
        embedded_profit_eur_per_day=math.nan,
        max_complementarity_product=math.nan,
        max_complementarity_violation=math.nan,
        primal_dual_gap_eur_per_day=math.nan,
    )
    monkeypatch.setattr(game, "clear", lambda *a: object())
    monkeypatch.setattr(game, "recleared_profit", lambda *a: 10.0)
    monkeypatch.setattr(game, "audit_state", lambda *a: {investor.investor_id: response})
    report = game.audit_equilibrium(data, config, state)
    assert not report.rows[0].audit_valid
    assert math.isnan(report.rows[0].profitable_deviation_eur_per_day)
    assert report.worst("profitable_deviation_eur_per_day") is None
    assert not report.passed


# ------------------------------------------------------------------ regression


def test_no_access_market_survives_anywhere():
    """The access market and its nodal tariff were removed.

    Both are gone for the same reason: they were symmetric shared costs that
    every investor faced identically, so they could only ever compress the
    capacity split towards equal shares. Nothing may quietly reintroduce
    either one.
    """

    for source in MODEL_DIR.glob("*.py"):
        text = source.read_text(encoding="utf-8").lower()
        assert "access_price" not in text, source.name
        assert "access market" not in text, source.name
        assert "system_capacity_limit" not in text, source.name
        assert "access_cost" not in text, source.name
        assert "access_alpha" not in text, source.name
        assert "access_beta" not in text, source.name


def test_solver_settings_reject_an_unknown_backend():
    with pytest.raises(ValueError):
        solvers.SolverSettings(market_backend="cplex")
    with pytest.raises(ValueError):
        replace(solvers.SolverSettings(), tolerance=0.0)
